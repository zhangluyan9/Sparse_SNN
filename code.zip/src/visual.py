from matplotlib import pyplot
def spike_to_image(x):
    pyplot.imshow(x)
    pyplot.savefig(x.jpg)